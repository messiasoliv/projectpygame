def BLACK ():
    return (0,0,0)
def WHITE ():
    return (255, 255, 255)
def GREEN ():
    return(0, 255, 0)
def RED ():
    return(255, 0, 0)
 
